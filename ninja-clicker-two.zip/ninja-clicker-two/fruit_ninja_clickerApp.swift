//
//  fruit_ninja_clickerApp.swift
//  fruit-ninja-clicker
//
//  Created by Ahmya Rivera on 10/27/25.
//

import SwiftUI

@main
struct fruit_ninja_clickerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
