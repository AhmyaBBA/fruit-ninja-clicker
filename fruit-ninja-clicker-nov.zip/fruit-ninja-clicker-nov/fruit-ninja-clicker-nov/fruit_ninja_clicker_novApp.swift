//
//  fruit_ninja_clicker_novApp.swift
//  fruit-ninja-clicker-nov
//
//  Created by Ahmya Rivera on 11/4/25.
//

import SwiftUI

@main
struct fruit_ninja_clicker_novApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
