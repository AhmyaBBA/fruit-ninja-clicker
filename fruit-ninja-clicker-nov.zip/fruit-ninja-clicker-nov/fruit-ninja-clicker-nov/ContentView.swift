//
//  ContentView.swift
//  fruit-ninja-clicker-nov
//
//

import SwiftUI
#if canImport(UIKit)
import UIKit
#endif

struct Prize: Identifiable, Hashable, Equatable {
    let threshold: Int
    let title: String
    let detail: String
    var id: Int { threshold }
}

enum Fruit: CaseIterable {
    case apple, banana, watermelon, orange, grape

    var emoji: String {
        switch self {
        case .apple: return "🍎"
        case .banana: return "🍌"
        case .watermelon: return "🍉"
        case .orange: return "🍊"
        case .grape: return "🍇"
        }
    }

    var name: String {
        switch self {
        case .apple: return "Apple"
        case .banana: return "Banana"
        case .watermelon: return "Watermelon"
        case .orange: return "Orange"
        case .grape: return "Grape"
        }
    }
}

struct ContentView: View {
    @State private var taps = 0
    @State private var currentFruit: Fruit = .apple
    @State private var earnedPrizes: [Prize] = []
    @State private var latestPrize: Prize?
    @State private var showPrizeAlert = false

    @State private var flyOffset: CGSize = .zero
    @State private var spin: Double = 0
    @State private var popScale: CGFloat = 1.0

    private let prizes: [Prize] = [
        Prize(threshold: 10,  title: "Wooden Blade 🗡️",      detail: "10 slices! Warming up."),
        Prize(threshold: 25,  title: "Steel Katana ⚔️",      detail: "25 slices! Getting sharp."),
        Prize(threshold: 50,  title: "Lightning Saber ⚡️",   detail: "50 slices! Blazing fast."),
        Prize(threshold: 100, title: "Grand Fruit Master 👑", detail: "100 slices! Legendary.")
    ]

    private let motionTimer = Timer.publish(every: 1.2, on: .main, in: .common).autoconnect()

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.green.opacity(0.25), .mint.opacity(0.25)],
                startPoint: .topLeading, endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(spacing: 22) {
                VStack(spacing: 6) {
                    Text("Fruit Ninja Clicker")
                        .font(.system(size: 28, weight: .bold))
                    Text("Clicks: \(taps)")
                        .font(.system(size: 36, weight: .heavy))
                        .monospacedDigit()
                        .accessibilityLabel("Total clicks \(taps)")
                }
                .padding(.top, 16)

                ZStack {
                    Button {
                        handleTap()
                    } label: {
                        Text(currentFruit.emoji)
                            .font(.system(size: 100))
                            .padding(24)
                            .background(.white.opacity(0.2))
                            .clipShape(RoundedRectangle(cornerRadius: 24))
                            .scaleEffect(popScale)
                            .rotationEffect(.degrees(spin))
                            .offset(flyOffset)
                            .shadow(color: .black.opacity(0.15), radius: 8, x: 0, y: 6)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Tap the \(currentFruit.name)")
                }
                .frame(height: 280)
                .padding(.vertical, 8)

                if !earnedPrizes.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Awards")
                            .font(.headline)
                        ForEach(earnedPrizes) { p in
                            Text("• \(p.title) — \(p.detail)")
                                .font(.subheadline)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.top, 4)
                }

                HStack(spacing: 12) {
                    Button {
                        taps = 0
                    } label: {
                        Label("Reset Count", systemImage: "arrow.counterclockwise")
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .background(.red.opacity(0.15))
                    .clipShape(Capsule())

                    Button {
                        resetGame()
                    } label: {
                        Label("New Game", systemImage: "sparkles")
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .background(.blue.opacity(0.15))
                    .clipShape(Capsule())
                }
                .font(.callout)

                Spacer(minLength: 0)
            }
            .padding(20)
        }
        .alert("Award Unlocked!", isPresented: $showPrizeAlert) {
            Button("Nice!") { }
        } message: {
            Text("\(latestPrize?.title ?? "")\n\(latestPrize?.detail ?? "")")
        }
        .onReceive(motionTimer) { _ in
            flyFruit()
        }
    }

    func handleTap() {
        taps += 1
        #if canImport(UIKit)
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        #endif
        withAnimation(.spring(response: 0.2, dampingFraction: 0.6)) { popScale = 1.12 }
        withAnimation(.spring(response: 0.35, dampingFraction: 0.7).delay(0.05)) { popScale = 1.0 }
        withAnimation(.easeIn(duration: 0.25)) { spin += 90 }
        unlockPrizesIfNeeded()
        currentFruit = Fruit.allCases.randomElement() ?? .apple
    }

    func flyFruit() {
        let maxX: CGFloat = 80
        let maxY: CGFloat = 60
        withAnimation(.easeInOut(duration: 1.0)) {
            flyOffset = CGSize(
                width: CGFloat.random(in: -maxX...maxX),
                height: CGFloat.random(in: -maxY...maxY)
            )
        }
    }

    func unlockPrizesIfNeeded() {
        let shouldHave = prizes.filter { $0.threshold <= taps }
        let newOnes = shouldHave.filter { p in !earnedPrizes.contains(p) }
        guard let newlyUnlocked = newOnes.sorted(by: { $0.threshold < $1.threshold }).last else { return }
        earnedPrizes.append(contentsOf: newOnes)
        latestPrize = newlyUnlocked
        showPrizeAlert = true
    }

    func resetGame() {
        taps = 0
        earnedPrizes.removeAll()
        latestPrize = nil
        currentFruit = .apple
        flyOffset = .zero
        spin = 0
        popScale = 1.0
    }
}

#Preview {
    ContentView()
}

