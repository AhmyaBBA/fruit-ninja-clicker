//
//  fruit_ninja_clicker_novTests.swift
//  fruit-ninja-clicker-novTests
//
//  Created by Ahmya Rivera on 11/4/25.
//

import Testing
@testable import fruit_ninja_clicker_nov

struct fruit_ninja_clicker_novTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
